# from django import forms

# from investigation.models.case import Case

# class CaseForm(forms.ModelForm):
#     class Meta:
#         model = Case
#         exclude = ["created_by", "status"]

#     def __init__(self, *args, **kwargs):
#         super(CaseForm, self).__init__(*args, **kwargs)

#         for field_name, field in self.fields.items():
#             field.widget.attrs["class"] = "form-control"