from django.contrib import admin

from stock_market.models.sentiment_analysis import EvaluationMetrics, MLPredictedSentiment
from .models import StockData
from .models import StockNews
from .models import SentimentAnalysis

# Register your models here.
class StockDataAdmin(admin.ModelAdmin):
    list_display = ('symbol', 'date', 'open_price', 'high_price', 'low_price', 'close_price', 'volume')
    search_fields = ('symbol',)

admin.site.register(StockData, StockDataAdmin)


class StockNewsAdmin(admin.ModelAdmin):
    list_display = ('source_name', 'author', 'title', 'published_at')
    search_fields = ('source_name', 'author', 'title')

admin.site.register(StockNews, StockNewsAdmin)

class SentimentAnalysisAdmin(admin.ModelAdmin):
    list_display = ('news', 'sentiment_score', 'sentiment_label', 'created_at')
    search_fields = ('news__title', 'sentiment_label')

admin.site.register(SentimentAnalysis, SentimentAnalysisAdmin)

class MLPredictedSentimentAdmin(admin.ModelAdmin):
    list_display = ('news', 'predicted_label', 'predicted_score', 'model_version', 'created_at')
    search_fields = ('news__title', 'predicted_label', 'model_version')

admin.site.register(MLPredictedSentiment, MLPredictedSentimentAdmin)


class EvaluationMetricsAdmin(admin.ModelAdmin):
    list_display = ('sector', 'accuracy', 'created_at')
    search_fields = ('sector__name',)

admin.site.register(EvaluationMetrics, EvaluationMetricsAdmin)