from django.urls import path

from stock_market.views.sector import SectorListView
from .views import (
    StockNewsListView, 
    StockNewsDetailView,
    StockDataListView, 
    StockDataDetailView,
    
)

urlpatterns = [
    path('stock_news/', StockNewsListView.as_view(), name="stock_news_list"),
    path('stock_news/<int:pk>/', StockNewsDetailView.as_view(), name="stock_news_detail"),
    
    path('stock_data/', StockDataListView.as_view(), name="stock_data_list"),
    path('stock_data/<int:pk>/', StockDataDetailView.as_view(), name="stock_data_detail"),
    path('sectors/', SectorListView.as_view(), name="sector_list"),
]
