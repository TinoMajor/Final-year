from typing import Any
from django.http import HttpRequest, HttpResponseRedirect
from django.http.response import HttpResponse as HttpResponse
from django.shortcuts import get_object_or_404, render, redirect
from django.views import View
from django.contrib.messages.views import SuccessMessageMixin
from django.urls import reverse
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin

from django.views.generic import (
    TemplateView,
    CreateView,
    DeleteView,
    DetailView,
    ListView,
    UpdateView,
)

from stock_market.models.sentiment_analysis import EvaluationMetrics, SentimentAnalysis
from stock_market.models.stock_data import StockData

from django.utils import timezone
from datetime import timedelta

from stock_market.models.stock_news import Sector, StockNews

class StockDataListView(LoginRequiredMixin, ListView):
    model = StockData
    context_object_name = "stock_data"
    template_name = "stock_data/index.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # Add underserved sectors
        context['underserved_sectors'] = get_underserved_sectors()

        return context

class StockDataDetailView(LoginRequiredMixin, DetailView):
    model = StockData
    context_object_name = "stock_data"
    template_name = "stock_data/detail.html"


from django.utils import timezone
from datetime import timedelta


def get_underserved_sectors(min_news=5, min_sentiment=5, days=30): #you can modify varibale here to check if sector is underserved/compliant like minimum news for that sector or minimum sentiment you can scale up or down liek we cant have a sector with 0 news or 0 sentiment and say its compliant
    recent_date = timezone.now() - timedelta(days=days)
    
    # Get all sectors
    sectors = Sector.objects.all()

    underserved = []

    for sector in sectors:
        news_count = StockNews.objects.filter(sector=sector,published_at__gte=recent_date).count()
        sentiment_count = SentimentAnalysis.objects.filter(news__sector=sector, created_at__gte=recent_date).count()
        metrics_exists = EvaluationMetrics.objects.filter(sector=sector).exists()

        if news_count < min_news or sentiment_count < min_sentiment or not metrics_exists:
            underserved.append({
                'sector': sector.name,
                'news_count': news_count,
                'sentiment_count': sentiment_count,
                'has_metrics': metrics_exists
            })

    return underserved


