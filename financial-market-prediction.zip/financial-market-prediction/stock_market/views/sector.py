from typing import Any
from django.http import HttpRequest, HttpResponseRedirect
from django.http.response import HttpResponse as HttpResponse
from django.shortcuts import get_object_or_404, render, redirect
from django.views import View
from django.contrib.messages.views import SuccessMessageMixin
from django.urls import reverse
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin

from django.views.generic import (
    TemplateView,
    CreateView,
    DeleteView,
    DetailView,
    ListView,
    UpdateView,
)

from stock_market.models.stock_news import Sector

class SectorListView(LoginRequiredMixin, ListView):
    model = Sector
    context_object_name = "sectors"
    template_name = "sector/index.html"
