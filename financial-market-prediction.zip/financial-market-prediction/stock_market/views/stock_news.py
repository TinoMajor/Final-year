from typing import Any
from django.http import HttpRequest, HttpResponseRedirect
from django.http.response import HttpResponse as HttpResponse
from django.shortcuts import get_object_or_404, render, redirect
from django.views import View
from django.contrib.messages.views import SuccessMessageMixin
from django.urls import reverse
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin

from django.views.generic import (
    TemplateView,
    CreateView,
    DeleteView,
    DetailView,
    ListView,
    UpdateView,
)

from stock_market.models.stock_news import StockNews

class StockNewsListView(LoginRequiredMixin, ListView):
    model = StockNews
    context_object_name = "stock_news"
    template_name = "stock_news/index.html"

class StockNewsDetailView(LoginRequiredMixin, DetailView):
    model = StockNews
    context_object_name = "stock_news"
    template_name = "stock_news/detail.html"






# class CaseCreateView(LoginRequiredMixin, SuccessMessageMixin, CreateView):
#     model = Case
#     form_class = CaseForm
#     template_name = "cases/create.html"
#     success_message = "Case created successfully"

#     def form_valid(self, form):
#         form.instance.created_by = self.request.user
#         return super().form_valid(form)

#     def get_success_url(self):
#         return reverse("statement_create")

# class CaseUpdateView(LoginRequiredMixin, SuccessMessageMixin,  UpdateView):
#     model = Case
#     template_name = "cases/update.html"
#     form_class = CaseForm
#     success_message = "Case updated successfully"

#     def get_success_url(self):
#         return reverse("case_list")

# class CaseDeleteView(LoginRequiredMixin, SuccessMessageMixin, View):
#     def get(self, request, **kwargs):
#         obj = get_object_or_404(Case, pk=kwargs.get("pk"))
#         obj.delete()
#         messages.success(request, f"{obj} deleted successfully")
#         return HttpResponseRedirect(request.META.get("HTTP_REFERER"))

# class CaseDetailView(LoginRequiredMixin, DetailView):
#     model = Case
#     context_object_name = "case"
#     template_name = "cases/detail.html"