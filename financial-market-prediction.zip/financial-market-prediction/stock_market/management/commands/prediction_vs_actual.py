from django.core.management.base import BaseCommand
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from stock_market.models.sentiment_analysis import EvaluationMetrics, MLPredictedSentiment
import numpy as np
import pandas as pd

from stock_market.models.stock_news import Sector

class Command(BaseCommand):
    help = 'Evaluate model predictions and store metrics per sector'

    def handle(self, *args, **kwargs):
        sectors = Sector.objects.all()
        total_evaluated = 0

        for sector in sectors:
            predictions = MLPredictedSentiment.objects.filter(news__sector=sector, evaluated_against__isnull=False)

            if not predictions.exists():
                self.stdout.write(f"⚠️ No evaluated predictions for sector {sector.name}")
                continue

            y_true = []
            y_pred = []

            for pred in predictions:
                y_true.append(pred.evaluated_against.sentiment_label)
                y_pred.append(pred.predicted_label)

            labels = ['positive', 'negative', 'neutral']
            accuracy = accuracy_score(y_true, y_pred)
            precision = dict(zip(labels, precision_score(y_true, y_pred, labels=labels, average=None, zero_division=0)))
            recall = dict(zip(labels, recall_score(y_true, y_pred, labels=labels, average=None, zero_division=0)))
            f1 = dict(zip(labels, f1_score(y_true, y_pred, labels=labels, average=None, zero_division=0)))
            matrix = pd.DataFrame(confusion_matrix(y_true, y_pred, labels=labels), index=labels, columns=labels).to_dict()

            # Save evaluation metrics
            EvaluationMetrics.objects.create(
                sector=sector,
                accuracy=accuracy,
                precision=precision,
                recall=recall,
                f1_score=f1,
                confusion_matrix=matrix
            )

            self.stdout.write(self.style.SUCCESS(f"✅ Metrics recorded for sector: {sector.name}"))
            total_evaluated += 1

        self.stdout.write(self.style.SUCCESS(f"🎯 Evaluation complete for {total_evaluated} sectors."))
