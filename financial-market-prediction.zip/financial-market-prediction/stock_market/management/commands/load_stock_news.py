
import requests
from django.core.management.base import BaseCommand
from django.utils.dateparse import parse_datetime
from django.utils.timezone import make_aware, is_naive
from stock_market.models.stock_news import Sector, StockNews
from datetime import datetime, timedelta

NEWS_API_KEY = '11b1c151cc764dd488cb5f38409d6edc'  # Replace with your actual key


class Command(BaseCommand):
    help = 'Fetch and store Zimbabwe sector-based news from the past 10 days (or within NewsAPI plan limits)'

    def handle(self, *args, **kwargs):
        # Define sectors and keywords
        sector_keywords = {
            "Banking": ["bank", "loan", "credit"],
            "Insurance": ["insurance", "premium", "claim"],
            "Capital Markets": ["stock", "shares", "exchange", "bourse"],
            "Microfinance": ["microfinance", "small loans", "informal sector"],
            "Fintech": ["fintech", "digital banking", "mobile money", "ecocash"],
        }

        # Ensure all sectors exist with descriptions (update or create)
        for sector_name, keywords in sector_keywords.items():
            description = f"Sector related to {', '.join(keywords)}."
            sector, created = Sector.objects.update_or_create(
            name=sector_name,
            defaults={"description": description}
            )
            if created:
                self.stdout.write(self.style.SUCCESS(f"✅ Created sector: {sector_name}"))
            else:
                self.stdout.write(self.style.SUCCESS(f"🔄 Updated sector: {sector_name}"))

        total_articles = 0
        total_added = 0

        # Determine date range (not earlier than NewsAPI plan limit)
        today = datetime.now()
        earliest_allowed = datetime(2025, 3, 18)
        from_date = max(today - timedelta(days=10), earliest_allowed).strftime("%Y-%m-%d")

        for sector_name, keywords in sector_keywords.items():
            # Use OR logic for keywords and add 'zimbabwe' relevance
            query = f"({' OR '.join(keywords)}) AND zimbabwe"
            url = (
                f"https://newsapi.org/v2/everything?"
                f"q={query}&"
                f"from={from_date}&"
                f"language=en&"
                f"sortBy=publishedAt&"
                f"pageSize=100&"
                f"apiKey={NEWS_API_KEY}"
            )

            response = requests.get(url)
            if response.status_code != 200:
                self.stdout.write(self.style.ERROR(f"Failed to fetch news for {sector_name}: {response.text}"))
                continue

            articles = response.json().get("articles", [])
            self.stdout.write(self.style.SUCCESS(f"{sector_name}: Fetched {len(articles)} articles."))

            for article in articles:
                title = article.get("title")
                description = article.get("description", "")
                content = article.get("content", "")
                url_link = article.get("url")

                # Skip if article already exists
                if StockNews.objects.filter(url=url_link).exists():
                    self.stdout.write(self.style.WARNING(f"⏭️ Skipped duplicate URL: {title}"))
                    continue

                published_at = article.get("publishedAt")
                if published_at:
                    published_at = parse_datetime(published_at)
                    if published_at and is_naive(published_at):
                        published_at = make_aware(published_at)

                # Create the news item
                StockNews.objects.create(
                    sector=Sector.objects.get(name=sector_name),
                    source_id=article["source"].get("id"),
                    source_name=article["source"].get("name"),
                    author=article.get("author"),
                    title=title,
                    description=description,
                    content=content,
                    url=url_link,
                    image_url=article.get("urlToImage"),
                    published_at=published_at
                )
                total_added += 1
                self.stdout.write(self.style.SUCCESS(f"✅ Added to {sector_name}: {title}"))

            total_articles += len(articles)

        self.stdout.write(self.style.SUCCESS(
            f"\n🎯 Done! Total articles fetched: {total_articles}, added: {total_added}"
        ))























# import requests
# from django.core.management.base import BaseCommand
# from django.utils.dateparse import parse_datetime
# from django.utils.timezone import make_aware, is_naive
# from stock_market.models.stock_news import Sector, StockNews

# NEWS_API_KEY = '11b1c151cc764dd488cb5f38409d6edc'  # Replace with your actual key


# class Command(BaseCommand):
#     help = 'Fetch and store real-time financial news for Zimbabwe by sector'

#     def handle(self, *args, **kwargs):
#         # Define sectors and keywords
#         sector_keywords = {
#             "Banking": ["bank", "loan", "credit"],
#             "Insurance": ["insurance", "premium", "claim"],
#             "Capital Markets": ["stock", "shares", "exchange", "bourse"],
#             "Microfinance": ["microfinance", "small loans", "informal sector"],
#             "Fintech": ["fintech", "digital banking", "mobile money", "ecocash"],
#         }

#         # Ensure all sectors exist
#         for sector_name in sector_keywords.keys():
#             Sector.objects.get_or_create(name=sector_name)

#         total_articles = 0
#         total_added = 0

#         for sector_name, keywords in sector_keywords.items():
#             query = "+".join(keywords)
#             url = (
#                 f"https://newsapi.org/v2/everything?"
#                 f"q={query}&"
#                 f"language=en&"
#                 f"sortBy=publishedAt&"
#                 f"pageSize=20&"
#                 f"apiKey={NEWS_API_KEY}"
#             )

#             response = requests.get(url)
#             if response.status_code != 200:
#                 self.stdout.write(self.style.ERROR(f"Failed to fetch news for {sector_name}: {response.text}"))
#                 continue

#             articles = response.json().get("articles", [])
#             self.stdout.write(self.style.SUCCESS(f"{sector_name}: Fetched {len(articles)} articles."))

#             for article in articles:
#                 title = article.get("title")
#                 description = article.get("description", "")
#                 content = article.get("content", "")
#                 url_link = article.get("url")

#                 # Ensure Zimbabwe relevance
#                 combined_text = f"{title} {description} {content}".lower()
#                 if "zimbabwe" not in combined_text:
#                     self.stdout.write(self.style.WARNING(f"⏭️ Not Zimbabwe related: {title}"))
#                     continue

#                 # Skip if article already exists
#                 if StockNews.objects.filter(url=url_link).exists():
#                     self.stdout.write(self.style.WARNING(f"⏭️ Skipped duplicate URL: {title}"))
#                     continue

#                 published_at = article.get("publishedAt")
#                 if published_at:
#                     published_at = parse_datetime(published_at)
#                     if published_at and is_naive(published_at):
#                         published_at = make_aware(published_at)

#                 # Create the news item
#                 StockNews.objects.create(
#                     sector=Sector.objects.get(name=sector_name),
#                     source_id=article["source"].get("id"),
#                     source_name=article["source"].get("name"),
#                     author=article.get("author"),
#                     title=title,
#                     description=description,
#                     content=content,
#                     url=url_link,
#                     image_url=article.get("urlToImage"),
#                     published_at=published_at
#                 )
#                 total_added += 1
#                 self.stdout.write(self.style.SUCCESS(f"✅ Added to {sector_name}: {title}"))

#             total_articles += len(articles)

#         self.stdout.write(self.style.SUCCESS(f"\n🎯 Done! Total articles fetched: {total_articles}, added: {total_added}"))

















# import requests
# from datetime import datetime
# from django.core.management.base import BaseCommand
# from stock_market.models import StockNews

# class Command(BaseCommand):
#     help = 'Fetch stock market news from NewsAPI'

#     def handle(self, *args, **kwargs):
#         self.stdout.write("Fetching stock news...")

#         api_key = '11b1c151cc764dd488cb5f38409d6edc' 
#         query = 'blockchain' 
#         from_date = '2025-02-08'
#         url = f'https://newsapi.org/v2/everything?q={query}&from={from_date}&sortBy=publishedAt&apiKey={api_key}'

#         response = requests.get(url)
#         if response.status_code == 200:
#             data = response.json()
            
#             if "articles" in data:
#                 for news in data["articles"]:
#                     source = news.get("source", {})
#                     source_id = source.get("id")
#                     source_name = source.get("name", "Unknown Source")
#                     title = news.get("title", "No Title Provided")
#                     description = news.get("description", "No Description Available")
#                     content = news.get("content", "No Content Available")
#                     url = news.get("url", "#")
#                     image_url = news.get("urlToImage", None)
#                     published_at = datetime.strptime(news["publishedAt"], "%Y-%m-%dT%H:%M:%SZ")
#                     author = news.get("author", None)

#                     # Check if news already exists
#                     if not StockNews.objects.filter(title=title, published_at=published_at).exists():
#                         StockNews.objects.create(
#                             source_id=source_id,
#                             source_name=source_name,
#                             author=author,
#                             title=title,
#                             description=description,
#                             content=content,
#                             url=url,
#                             image_url=image_url,
#                             published_at=published_at,
#                         )
#                         self.stdout.write(f'Created news entry: {title} - {published_at}')

#                 self.stdout.write(self.style.SUCCESS('Stock news updated successfully.'))
#             else:
#                 self.stdout.write(self.style.ERROR('No articles found in response.'))
#         else:
#             self.stdout.write(self.style.ERROR(f'Failed to fetch stock news. Status Code: {response.status_code}'))
#             print(response.json())  # Debugging output
