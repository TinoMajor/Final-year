import datetime
import requests
from django.utils.timezone import make_aware
from django.core.management.base import BaseCommand
from stock_market.models import StockNews

API_KEY = "pub_776383da5582707f285af4d7d4bc278985458"
API_URL = "https://newsdata.io/api/1/news"

SECTORS = {
    "banking": "banking",
    "capital_markets": "capital markets",
    "insurance": "insurance",
    "microfinance": "microfinance",
}

ZIM_COUNTRY_CODE = "zw"
LANG = "en"

class Command(BaseCommand):
    help = "Fetches Zimbabwean financial news from Newsdata.io API for predefined sectors."

    def handle(self, *args, **kwargs):
        self.stdout.write("🚀 Starting to fetch API-based Zimbabwe stock news...")

        for sector_key, query in SECTORS.items():
            self.stdout.write(f"\n🔎 Fetching for sector: {sector_key} | query: {query}")

            page = 1
            while True:
                params = {
                    "apikey": API_KEY,
                    "q": query,
                    "country": ZIM_COUNTRY_CODE,
                    "language": LANG,
                    "page": page,
                }

                response = requests.get(API_URL, params=params)
                data = response.json()

                if response.status_code != 200:
                    self.stderr.write(f"❌ Error fetching data: {data.get('message') or response.text}")
                    break

                results = data.get("results", [])
                if not results:
                    self.stdout.write("✅ No more results.")
                    break

                for item in results:
                    title = item.get("title")
                    url = item.get("link")
                    source = item.get("source_id") or "Newsdata.io"
                    description = item.get("description") or ""
                    pub_date = item.get("pubDate")

                    if not title or not url:
                        continue

                    if StockNews.objects.filter(title=title).exists():
                        self.stdout.write(f"⚠️ Skipping (already exists): {title}")
                        continue

                    try:
                        published_at = make_aware(datetime.datetime.strptime(pub_date, "%Y-%m-%d %H:%M:%S"))
                    except:
                        published_at = make_aware(datetime.datetime.now())

                    StockNews.objects.create(
                        sector=sector_key,
                        source_name=source,
                        title=title,
                        description=description,
                        content="Not available",
                        url=url,
                        published_at=published_at,
                    )
                    self.stdout.write(self.style.SUCCESS(f"✅ Saved: {title}"))

                if not data.get("nextPage"):
                    break

                page += 1

        self.stdout.write(self.style.SUCCESS("\n🎉 Finished fetching all sector news from API."))
