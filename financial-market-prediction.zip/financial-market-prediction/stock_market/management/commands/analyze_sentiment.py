import nltk
from nltk.sentiment import SentimentIntensityAnalyzer
from django.core.management.base import BaseCommand
from django.db import transaction

from stock_market.models.sentiment_analysis import SentimentAnalysis
from stock_market.models.stock_news import StockNews
import time
import logging

# Ensure NLTK has the required data
nltk.download('vader_lexicon')

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class Command(BaseCommand):
    help = 'Analyzes sentiment of financial news and stores results'

    def handle(self, *args, **kwargs):
        sia = SentimentIntensityAnalyzer()
        analyzed_count = 0
        start_time = time.time()
        end_time = start_time + 60  # Run for 1 minute

        # Select all news articles from StockNews
        news_queryset = StockNews.objects.select_related('sector').all()
        total_news = news_queryset.count()
        processed_news = 0

        logging.info(f'Starting sentiment analysis for {total_news} news items')

        # Iterate over each news article
        for news in news_queryset:
            current_time = time.time()
            if current_time >= end_time:
                logging.info("⏳ Time limit reached. Ending early.")
                break

            processed_news += 1
            progress = min(int((processed_news / total_news) * 100), 100)
            logging.info(f'Progress: {progress}%')

            if not SentimentAnalysis.objects.filter(news=news).exists():
                try:
                    description = news.description or ""
                    score = sia.polarity_scores(description)['compound']

                    if score >= 0.05:
                        label = "positive"
                    elif score <= -0.05:
                        label = "negative"
                    else:
                        label = "neutral"

                    # Create SentimentAnalysis record
                    with transaction.atomic():
                        SentimentAnalysis.objects.create(
                            news=news,
                            sentiment_score=score,
                            sentiment_label=label
                        )

                    analyzed_count += 1

                except Exception as e:
                    logging.error(f"Error analyzing news ID {news.id}: {str(e)}")

        self.stdout.write(self.style.SUCCESS(f"🎯 Sentiment Analysis Completed: {analyzed_count} new entries added"))
        logging.info("✅ Sentiment Analysis Finished Successfully.")
