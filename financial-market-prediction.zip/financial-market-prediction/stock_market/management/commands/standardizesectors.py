from django.core.management.base import BaseCommand
from django.db import transaction
from stock_market.models.stock_news import Sector, StockNews
from stock_market.models.sentiment_analysis import EvaluationMetrics
import re # Import the regular expression module

class Command(BaseCommand):
    help = 'Merges duplicate sector entries after normalizing names.'

    def handle(self, *args, **options):
        self.stdout.write("Merging duplicate sector entries after normalizing names...")

        # Group sectors by normalized name (lowercase, no spaces or underscores)
        sectors_by_normalized_name = {}
        for sector in Sector.objects.all():
            # Normalize the name: lowercase, remove spaces and underscores
            normalized_name = re.sub(r'[ _]', '', sector.name).lower()

            if normalized_name not in sectors_by_normalized_name:
                sectors_by_normalized_name[normalized_name] = []
            sectors_by_normalized_name[normalized_name].append(sector)

        duplicates_found = False
        for normalized_name, sectors_list in sectors_by_normalized_name.items():
            if len(sectors_list) > 1:
                duplicates_found = True
                self.stdout.write(f"Found duplicates for normalized name '{normalized_name}': {[s.name for s in sectors_list]}")

                # Identify the sector to keep (we'll keep the first one found with the normalized name if possible)
                main_sector = None
                for sector in sectors_list:
                    if re.sub(r'[ _]', '', sector.name).lower() == normalized_name:
                         main_sector = sector
                         break

                # If no exact normalized name exists among the duplicates, pick the first one in the list
                if not main_sector:
                    main_sector = sectors_list[0]
                    # We won't change the name of the main sector here, as the user might prefer the original formatting


                # Merge related objects and delete duplicates
                with transaction.atomic():
                    for sector_to_delete in sectors_list:
                        if sector_to_delete != main_sector:
                            self.stdout.write(f"  Merging data from sector '{sector_to_delete.name}' (ID: {sector_to_delete.id}) to '{main_sector.name}' (ID: {main_sector.id})")

                            # Update StockNews relationships
                            StockNews.objects.filter(sector=sector_to_delete).update(sector=main_sector)

                            # Update EvaluationMetrics relationships
                            EvaluationMetrics.objects.filter(sector=sector_to_delete).update(sector=main_sector)

                            # Delete the duplicate sector
                            sector_to_delete.delete()
                            self.stdout.write(f"  Deleted duplicate sector: '{sector_to_delete.name}' (ID: {sector_to_delete.id})")

        if not duplicates_found:
            self.stdout.write("No duplicate sector entries found after normalization.")

        self.stdout.write("Duplicate sector merging complete.")
