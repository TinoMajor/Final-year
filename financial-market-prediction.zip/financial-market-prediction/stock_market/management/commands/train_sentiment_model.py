# stock_market/management/commands/predict_sentiment.py

from django.core.management.base import BaseCommand
from stock_market.models.stock_news import StockNews
from stock_market.models.sentiment_analysis import SentimentAnalysis, MLPredictedSentiment
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import joblib
import os

class Command(BaseCommand):
    help = 'Train or load ML model to predict sentiment and apply to financial news'

    def handle(self, *args, **kwargs):
        self.stdout.write(self.style.NOTICE("🔍 Starting ML sentiment prediction..."))

        # Load or train model
        model_path = 'sentiment_model.pkl'
        vectorizer_path = 'vectorizer.pkl'

        if os.path.exists(model_path) and os.path.exists(vectorizer_path):
            model = joblib.load(model_path)
            vectorizer = joblib.load(vectorizer_path)
            self.stdout.write("✅ Loaded existing model and vectorizer")
        else:
            self.stdout.write("🧠 Training model...")
            training_data = SentimentAnalysis.objects.select_related('news').all()
            texts = [entry.news.description or '' for entry in training_data]
            labels = [entry.sentiment_label for entry in training_data]

            vectorizer = TfidfVectorizer(stop_words='english')
            X = vectorizer.fit_transform(texts)
            model = LogisticRegression(max_iter=200)
            model.fit(X, labels)

            joblib.dump(model, model_path)
            joblib.dump(vectorizer, vectorizer_path)
            self.stdout.write("✅ Model trained and saved")

        # Predict on unprocessed news
        unpredicted_news = StockNews.objects.exclude(
            mlpredictedsentiment__isnull=False
        )

        count = 0
        for news in unpredicted_news:
            text = news.description or ''
            X = vectorizer.transform([text])
            label = model.predict(X)[0]
            score = max(model.predict_proba(X)[0])

            reference = SentimentAnalysis.objects.filter(news=news).first()

            MLPredictedSentiment.objects.create(
                news=news,
                predicted_label=label,
                predicted_score=score,
                model_version='v1',
                evaluated_against=reference
            )
            count += 1
            self.stdout.write(f"🔹 {news.title[:60]}... → {label} ({round(score, 2)})")

        self.stdout.write(self.style.SUCCESS(f"🎯 ML Predictions Complete: {count} entries created."))
