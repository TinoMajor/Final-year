# import datetime
# from django.core.management.base import BaseCommand
# from newsapi import NewsApiClient

# from stock_market.models.stock_news import StockNews

# # Set up API key
# API_KEY = "11b1c151cc764dd488cb5f38409d6edc"

# # Define financial sectors to fetch news for
# SECTORS = {
#     "banking": "banking Zimbabwe",
#     "capital_markets": "capital markets Zimbabwe",
#     "insurance": "insurance Zimbabwe",
#     "microfinance": "microfinance Zimbabwe",
# }

# # Date range: Today to January 1st of last year
# END_DATE = datetime.date.today()
# START_DATE = datetime.date(END_DATE.year, 3, 1)  # January 1st of this year

# class Command(BaseCommand):
#     help = "Fetches and loads Zimbabwean financial news into the StockNews model from today up to January 1st of last year"

#     def handle(self, *args, **kwargs):
#         self.stdout.write("Fetching financial news...")
#         newsapi = NewsApiClient(api_key=API_KEY)
        
#         # Iterate over each day in the range
#         current_date = START_DATE
#         while current_date <= END_DATE:
#             formatted_date = current_date.strftime("%Y-%m-%d")
#             self.stdout.write(f"\nFetching news for date: {formatted_date}")

#             for sector, query in SECTORS.items():
#                 self.stdout.write(f"  Sector: {sector}")

#                 try:
#                     articles = newsapi.get_everything(
#                         q=query, 
#                         language="en", 
#                         sort_by="publishedAt", 
#                         from_param=formatted_date, 
#                         to=formatted_date,  # Fetch news only for the specific day
#                         page_size=10
#                     )

#                     for article in articles.get("articles", []):
#                         stock_news, created = StockNews.objects.get_or_create(
#                             title=article["title"],
#                             defaults={
#                                 "sector": sector,
#                                 "source_id": article["source"].get("id", ""),
#                                 "source_name": article["source"].get("name", ""),
#                                 "author": article.get("author", "Unknown"),
#                                 "description": article.get("description", ""),
#                                 "content": article.get("content", ""),
#                                 "url": article["url"],
#                                 "image_url": article.get("urlToImage", ""),
#                                 "published_at": article["publishedAt"],
#                             }
#                         )

#                         if created:
#                             self.stdout.write(f"    Added: {article['title']}")
#                         else:
#                             self.stdout.write(f"    Skipped (already exists): {article['title']}")

#                 except Exception as e:
#                     self.stderr.write(f"  Error fetching news for {sector} on {formatted_date}: {e}")

#             current_date += datetime.timedelta(days=1)  # Move to the next day

#         self.stdout.write("\nNews loading completed successfully!")


import time
import datetime
from bs4 import BeautifulSoup
from django.utils.timezone import make_aware
from django.core.management.base import BaseCommand
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from stock_market.models import StockNews
from stock_market.models.stock_news import Sector  # Import Sector from its specific module


SECTORS = {
    "banking": "banking",
    "capital_markets": "capital markets",
    "insurance": "insurance",
    "microfinance": "microfinance",
}

NEWS_SOURCES = [
    "https://www.newsday.co.zw",
    "https://www.thezimbabwemail.com",
    "https://www.bulawayo24.com",
]

class Command(BaseCommand):
    help = "Scrapes and stores Zimbabwean financial news using Selenium (headless)."

    def add_arguments(self, parser):
        parser.add_argument(
            '--date',
            type=str,
            help='Specific date to scrape in format YYYY-MM-DD (defaults to today if not provided)'
        )

    def handle(self, *args, **options):
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        driver = webdriver.Chrome(options=chrome_options)

        try:
            # Parse provided date or fallback to today
            if options['date']:
                try:
                    target_date = datetime.datetime.strptime(options['date'], "%Y-%m-%d").date()
                except ValueError:
                    self.stderr.write(self.style.ERROR("❌ Invalid date format. Use YYYY-MM-DD."))
                    return
            else:
                target_date = datetime.date.today()

            self.stdout.write(f"🚀 Scraping news for 📅 {target_date}")

            # Fetch all sectors once before the loop
            sector_objects = {sector.name: sector for sector in Sector.objects.all()}

            for sector_name, query in SECTORS.items():
                self.stdout.write(f"🔎 Sector: {sector_name}")

                # Get the Sector object for the current sector name
                sector_instance = sector_objects.get(sector_name)
                if not sector_instance:
                    self.stderr.write(self.style.ERROR(f"❌ Sector '{sector_name}' not found in database. Skipping."))
                    continue


                for base_url in NEWS_SOURCES:
                    search_url = f"{base_url}/search/{query.replace(' ', '%20')}"
                    self.stdout.write(f"🌍 Source: {base_url}")

                    try:
                        driver.get(search_url)
                        time.sleep(3)  # Let page load

                        soup = BeautifulSoup(driver.page_source, "html.parser")
                        articles = soup.find_all(["article", "div"], class_=["news-item", "post", "search-result"])

                        for item in articles:
                            title_tag = item.find(["h2", "h3"])
                            link_tag = item.find("a", href=True)
                            desc_tag = item.find("p")
                            date_tag = item.find("time")

                            title = title_tag.get_text(strip=True) if title_tag else None
                            url = link_tag["href"] if link_tag else None
                            description = desc_tag.get_text(strip=True) if desc_tag else None

                            if url and not url.startswith("http"):
                                url = base_url + url

                            try:
                                published_at = (
                                    make_aware(datetime.datetime.strptime(date_tag["datetime"], "%Y-%m-%dT%H:%M:%S"))
                                    if date_tag and date_tag.has_attr("datetime")
                                    else make_aware(datetime.datetime.combine(target_date, datetime.time.min))
                                )
                            except:
                                published_at = make_aware(datetime.datetime.combine(target_date, datetime.time.min))

                            if title and url and not StockNews.objects.filter(title=title).exists():
                                StockNews.objects.create(
                                    sector=sector_instance,  # Assign the Sector object
                                    source_name=base_url,
                                    title=title,
                                    description=description,
                                    content="Not available",
                                    url=url,
                                    published_at=published_at,
                                )
                                self.stdout.write(self.style.SUCCESS(f"✅ Saved: {title}"))
                            else:
                                self.stdout.write(self.style.WARNING(f"⚠️ Skipped: {title}"))

                    except Exception as e:
                        self.stderr.write(self.style.ERROR(f"❌ Failed to fetch from {base_url}: {e}"))

            self.stdout.write(self.style.SUCCESS("🎉 Scraping complete.\n")) # Added newline

        finally:
            driver.quit()
            self.stdout.write("🧹 Browser closed.")
