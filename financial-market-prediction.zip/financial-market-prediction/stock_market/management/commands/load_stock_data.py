import requests
from datetime import datetime
from django.core.management.base import BaseCommand
import logging
from stock_market.models import StockData  
import logging

# Configure logging (ensure this is set in your main script or settings)
logging.basicConfig(
    filename='stock_data.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Configure logging
logging.basicConfig(
    filename='/Users/couragemhute/Desktop/courage/projects/uni/financial_market_prediction/stock_market/management/commands/load_stock_data.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

API_KEY = "VFQX8P6T9GYQHT11"  # Replace with your own API key

def fetch_stock_data(symbol="IBM"):
    """Fetch stock data from Alpha Vantage and save it to the database"""
    url = f"https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol={symbol}&apikey={API_KEY}"
    logging.info(f"Fetching data from URL: {url}")
    response = requests.get(url).json()

    if "Time Series (Daily)" in response:
        for date, values in response["Time Series (Daily)"].items():
            date_obj = datetime.strptime(date, "%Y-%m-%d").date()

        # Check if data already exists
        if not StockData.objects.filter(symbol=symbol, date=date_obj).exists():
            StockData.objects.create(
                symbol=symbol,
                date=date_obj,
                open_price=float(values["1. open"]),
                high_price=float(values["2. high"]),
                low_price=float(values["3. low"]),
                close_price=float(values["4. close"]),
                volume=int(values["5. volume"]),
            )
            logging.info(
                f"Created new stock data for {symbol} on {date_obj} | Open: {values['1. open']}, "
                f"High: {values['2. high']}, Low: {values['3. low']}, Close: {values['4. close']}, Volume: {values['5. volume']}"
            )

        return f"Stock data for {symbol} updated."
    else:
        logging.error(f"Failed to fetch stock data for {symbol}: {response}")
        return "Failed to fetch stock data."


class Command(BaseCommand):
    help = "Fetches stock data from Alpha Vantage and stores it in the database"

    def add_arguments(self, parser):
        parser.add_argument("symbol", type=str, help="Stock symbol to fetch data for")

    def handle(self, *args, **options):
        symbol = options["symbol"]
        self.stdout.write(f"Fetching stock data for {symbol}...")
        logging.info(f"Fetching stock data for {symbol}")
        result = fetch_stock_data(symbol)
        self.stdout.write(self.style.SUCCESS(result))
        logging.info(result)
