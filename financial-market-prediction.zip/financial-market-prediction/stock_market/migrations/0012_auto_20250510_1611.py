from django.db import migrations

def create_sectors(apps, schema_editor):
    Sector = apps.get_model('stock_market', 'Sector')
    sectors_to_create = [
        'banking',
        'capital_markets',
        'insurance',
        'microfinance',
    ]
    for sector_name in sectors_to_create:
        Sector.objects.get_or_create(name=sector_name)

class Migration(migrations.Migration):

    dependencies = [
        ('stock_market', '0011_alter_evaluationmetrics_confusion_matrix_and_more')
    ]

    operations = [
        migrations.RunPython(create_sectors),
    ]
