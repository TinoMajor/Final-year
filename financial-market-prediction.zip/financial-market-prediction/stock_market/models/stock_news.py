from django.db import models

class Sector(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    def __str__(self):
        return self.name


class StockNews(models.Model):
    sector = models.ForeignKey(Sector, on_delete=models.SET_NULL, blank=True, null=True)  
    source_id = models.CharField(max_length=255, blank=True, null=True)  # Source ID (nullable)
    source_name = models.CharField(max_length=255, blank=True, null=True)  # Source Name (nullable)
    author = models.CharField(max_length=255, blank=True, null=True)  # Author (nullable)
    title = models.CharField(max_length=500, blank=True, null=True)  # News Title (nullable)
    description = models.TextField(blank=True, null=True)  # News Description (nullable)
    content = models.TextField(blank=True, null=True)  # Full Content (nullable)
    url = models.URLField(blank=True, null=True)  # News URL (nullable)
    image_url = models.URLField(blank=True, null=True)  # Image URL (nullable)
    published_at = models.DateTimeField(null=True, blank=True)  # Published Date (nullable)

    def __str__(self):
        return f"{self.title} - {self.source_name}"
