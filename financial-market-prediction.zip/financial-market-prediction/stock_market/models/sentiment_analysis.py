from django.db import models
from django.core.serializers.json import DjangoJSONEncoder

class SentimentAnalysis(models.Model):
    news = models.ForeignKey('StockNews', on_delete=models.CASCADE)  # Link to news
    sentiment_score = models.FloatField()  # Sentiment score (-1 to +1)
    sentiment_label = models.CharField(
        max_length=10,
        choices=[('positive', 'Positive'), ('negative', 'Negative'), ('neutral', 'Neutral')]
    )
    created_at = models.DateTimeField(auto_now_add=True)  # Timestamp of analysis

    def __str__(self):
        return f"{self.news} - {self.sentiment_label} ({self.sentiment_score})"


class MLPredictedSentiment(models.Model):
    news = models.ForeignKey('StockNews', on_delete=models.CASCADE)
    predicted_label = models.CharField(
        max_length=10,
        choices=[('positive', 'Positive'), ('negative', 'Negative'), ('neutral', 'Neutral')]
    )
    predicted_score = models.FloatField()  # Confidence/probability
    model_version = models.CharField(max_length=20, default='v1')
    evaluated_against = models.ForeignKey(
        'SentimentAnalysis',
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.news.title} - {self.predicted_label} ({round(self.predicted_score, 2)})"


class EvaluationMetrics(models.Model):
    sector = models.ForeignKey('stock_market.Sector', on_delete=models.CASCADE)
    accuracy = models.FloatField()
    precision = models.JSONField(encoder=DjangoJSONEncoder)  # Changed to JSONField
    recall = models.JSONField(encoder=DjangoJSONEncoder)      # Changed to JSONField
    f1_score = models.JSONField(encoder=DjangoJSONEncoder)    # Changed to JSONField
    confusion_matrix = models.JSONField(encoder=DjangoJSONEncoder) # Changed to JSONField
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Metrics for {self.sector.name}"
