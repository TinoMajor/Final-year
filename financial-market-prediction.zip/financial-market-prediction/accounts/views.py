import plotly.graph_objs as go
from plotly.offline import plot
from django.views.generic import ListView
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.urls import reverse
from django.views.generic import ListView, UpdateView, DeleteView, View
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.models import User
from .forms import CustomUserCreationForm, CustomUserUpdateForm, SimpleCustomUserCreationForm
from django.contrib.auth.views import PasswordResetView
from django.template.loader import render_to_string
from django.core.mail import EmailMessage
from django.contrib.auth.views import PasswordResetView
# Corrected import statements for models in the 'models' subdirectory
from stock_market.models.sentiment_analysis import SentimentAnalysis, MLPredictedSentiment
from stock_market.models.stock_news import StockNews
# If you use StockData model, uncomment the next line
# from stock_market.models.stock_data import StockData
from django.db.models import Avg, Count
from django.db.models.functions import TruncDate
from django.utils import timezone
from sklearn.metrics import confusion_matrix
import numpy as np

def login_user(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, (f"You have successfully logged in as: {user.username}"))
            return redirect('dashboard')
        else:
            messages.error(request, ("Invalid username or password."))
            return redirect('login')
    else:
        return render(request, 'registration/login.html', {})

class UserListView(ListView):
    model = User
    template_name = 'registration/index.html'

class GraphsView(ListView):
    model = User
    template_name = 'registration/graphs.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # --- Data for Line Chart ---
        # Example: Average sentiment score over time
        # Get the average sentiment per day for the last 30 days
        today = timezone.now()
        thirty_days_ago = today - timezone.timedelta(days=90)

        # Correct way of getting the data
        sentiment_over_time = SentimentAnalysis.objects.filter(
                created_at__range=(thirty_days_ago, today)
            ).annotate(date=TruncDate('created_at')).values('date').annotate(avg_sentiment=Avg('sentiment_score')).order_by('date')

        # Extract data for Plotly
        x_data = [item['date'] for item in sentiment_over_time]
        y_data = [item['avg_sentiment'] for item in sentiment_over_time]

        # Create line plot
        if x_data and y_data:
            trace = go.Scatter(x=x_data, y=y_data, mode='lines+markers', name='Average Sentiment')
            layout = go.Layout(title='Average Sentiment Over Time', xaxis=dict(title='Date', type='date'), yaxis=dict(title='Average Sentiment'))
            fig = go.Figure(data=[trace], layout=layout)
            context['plot_div'] = plot(fig, output_type='div', include_plotlyjs=False)
        else:
             context['plot_div'] = '<p>No sentiment data available for the last 30 days.</p>'

        # --- Data for Scatter Plot ---
        # Get the sentiment score and news_count for each sector
        sentiment_vs_news = StockNews.objects.values('sector__name').annotate(
            avg_sentiment=Avg('sentimentanalysis__sentiment_score'),
            news_count=Count('id')
        ).filter(sentimentanalysis__isnull=False)

        # Extract data for Plotly
        sectors = [item['sector__name'] for item in sentiment_vs_news]
        avg_sentiments = [item['avg_sentiment'] for item in sentiment_vs_news]
        news_counts = [item['news_count'] for item in sentiment_vs_news]

        # Create scatter plot
        scatter_trace = go.Scatter(x=avg_sentiments, y=news_counts, mode='markers', marker=dict(size=10, color='orange'), text=sectors, name='Sentiment vs News Count')
        scatter_layout = go.Layout(title='Sentiment Score vs. News Count by Sector', xaxis=dict(title='Average Sentiment Score',color='black'), yaxis=dict(title='News Count'))
        scatter_fig = go.Figure(data=[scatter_trace], layout=scatter_layout)
        context['scatter_plot_div'] = plot(scatter_fig, output_type='div', include_plotlyjs=False)

        # --- Data for Pie Chart ---
        # Get the sentiment distribution
        sentiment_distribution = SentimentAnalysis.objects.values('sentiment_label').annotate(label_count=Count('id'))

        # Extract data for Plotly
        labels = [item['sentiment_label'] for item in sentiment_distribution]
        values = [item['label_count'] for item in sentiment_distribution]

        # Create pie chart
        pie_trace = go.Pie(labels=labels, values=values, hole=0.3)
        pie_layout = go.Layout(title='Sentiment Distribution')
        pie_fig = go.Figure(data=[pie_trace], layout=pie_layout)
        context['pie_chart_div'] = plot(pie_fig, output_type='div', include_plotlyjs=False)

        # --- Data for Confusion Matrix ---
        true_labels = []
        predicted_labels = []

        # Fetch true and predicted labels
        predicted_sentiments = MLPredictedSentiment.objects.filter(evaluated_against__isnull=False)

        # Added check for the number of predicted sentiments fetched
        print(f"Number of predicted sentiments with evaluated_against: {predicted_sentiments.count()}")

        for prediction in predicted_sentiments:
            # Added checks for missing labels
            if hasattr(prediction, 'evaluated_against') and prediction.evaluated_against and hasattr(prediction.evaluated_against, 'sentiment_label') and prediction.evaluated_against.sentiment_label:
                 true_labels.append(prediction.evaluated_against.sentiment_label)
            else:
                 print(f"Skipping prediction {prediction.id}: Missing evaluated_against or sentiment_label")

            if hasattr(prediction, 'predicted_label') and prediction.predicted_label:
                 predicted_labels.append(prediction.predicted_label)
            else:
                 print(f"Skipping prediction {prediction.id}: Missing predicted_label")

        # Added checks for the number of labels collected
        print(f"Number of true labels collected: {len(true_labels)}")
        print(f"Number of predicted labels collected: {len(predicted_labels)}")

        # Define the possible labels
        all_labels = sorted(list(set(true_labels + predicted_labels)))

        # Compute confusion matrix
        if true_labels and predicted_labels:
            cm = confusion_matrix(true_labels, predicted_labels, labels=all_labels)
            context['confusion_matrix'] = cm.tolist()
            context['confusion_matrix_labels'] = all_labels
        else:
            context['confusion_matrix'] = None
            context['confusion_matrix_labels'] = []
            # Added message indicating if the confusion matrix is not calculated
            print("Confusion matrix not calculated: true_labels or predicted_labels is empty.")

        # Debugging print statements
        print("Confusion Matrix Data (in context):", context.get('confusion_matrix'))
        print("Confusion Matrix Labels (in context):", context.get('confusion_matrix_labels'))


        return context

def register_user(request):
        if request.method == "GET":
            return render(
                request, "registration/create.html",
                {"form": CustomUserCreationForm}
            )
        elif request.method == "POST":
            form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, ("User created successfully"))
            return redirect('users-index')
        else:
            messages.error(request, ("Something went wrong please try again"))
            return redirect('register-user')

class UserUpdateView(UpdateView):
    model = User
    template_name = 'registration/update.html'
    form_class = CustomUserUpdateForm
    success_message = "User updated successfully"
    def get_success_url(self):
        return reverse("users-index")

class UserDeleteView(DeleteView):
    model = User
    success_message = "User deleted successfully"

    def get_success_url(self):
        return reverse("users-index")

#Custom email reset

class CustomPasswordResetView(PasswordResetView):
    email_template_name = 'account/password_reset_email.html'
    html_email_template_name = 'account/password_reset_email.html'

    def send_mail(self, subject_template_name, email_template_name, context, from_email, to_email, html_email_template_name=None):
        html_email = render_to_string(html_email_template_name, context)
        email_message = EmailMessage(
            subject_template_name,
            html_email,
            from_email,
            [to_email],
        )

        email_message.content_subtype = 'html'
        email_message.send()

class RegisterUserView(View):
    def get(self, request):
        form = SimpleCustomUserCreationForm()
        return render(request, "registration/signup.html", {"form": form})

    def post(self, request):
        form = SimpleCustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            # Assign role to Basic User
            user = form.instance
            user.role = "Basic User"
            user.save()
            messages.success(request, "User created successfully")
            return redirect('login')
        else:
            messages.error(request, f"Something went wrong: {form.errors.as_json()}")
            return render(request, "registration/signup.html", {"form": form})


class SimplePasswordResetView(View):
    def get(self, request):
        return render(request, "registration/password_reset.html")

    def post(self, request):
        email = request.POST.get("email")
        new_password = request.POST.get("new_password")
        confirm_password = request.POST.get("confirm_password")

        if new_password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return render(request, "registration/password_reset.html")

        user = User.objects.filter(email=email).first()
        if not user:
            messages.error(request, "No user found with the provided email.")
            return render(request, "registration/password_reset.html")
        # Reset password
        user.set_password(new_password)
        user.save()
        messages.success(request, "Password reset successfully. You can now log in.")
        return redirect("login")
