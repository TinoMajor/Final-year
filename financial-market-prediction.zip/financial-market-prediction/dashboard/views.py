from logging import info
from django.shortcuts import render, redirect
from django.views.generic import TemplateView
from django.contrib import messages
from django.db import models
from stock_market.models.stock_data import StockData
from stock_market.models.stock_news import Sector, StockNews
from stock_market.models.sentiment_analysis import EvaluationMetrics, SentimentAnalysis
from django.views.generic import TemplateView
from django.db.models import Count
import json

from stock_market.views.stock_data import get_underserved_sectors

class DashboardListView(TemplateView):   
    template_name = 'dashboard/dashboard.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['stock_news_count'] = StockNews.objects.count()
        context['stock_data_count'] = StockData.objects.count()
        context['underserved_sectors'] = get_underserved_sectors()

        # Get sentiment counts
        sentiment_labels, sentiment_values = self.get_sentiment_counts()
        context['sentiment_labels'] = sentiment_labels
        context['sentiment_values'] = sentiment_values

        # Get stock price data
        stock_dates, open_prices, close_prices, high_prices, low_prices = self.get_stock_price_data()
        context['stock_dates'] = stock_dates
        context['open_prices'] = open_prices
        context['close_prices'] = close_prices
        context['high_prices'] = high_prices
        context['low_prices'] = low_prices

        # Get stock news data
        news_dates, news_counts = self.get_stock_news_data()
        context['news_dates'] = news_dates
        context['news_counts'] = news_counts
        
        sectors, sentiment_values = get_sentiment_counts_per_sector()
        context['sectors'] = sectors
        context['sentiment_values'] = sentiment_values
        
        all_sectors, accuracy_metrics  = get_evaluation_metrics_per_sector()
        context['all_sectors'] = all_sectors
        context['accuracy_metrics'] = accuracy_metrics
        


        return context

    def get_sentiment_counts(self):
        sentiment_counts = SentimentAnalysis.objects.values('sentiment_label').annotate(count=Count('sentiment_label'))
        sentiment_labels = [item['sentiment_label'] for item in sentiment_counts]
        sentiment_values = [item['count'] for item in sentiment_counts]
        return sentiment_labels, sentiment_values

    def get_stock_price_data(self):
        stock_data = StockData.objects.order_by('date')
        stock_dates = json.dumps([stock.date.strftime('%Y-%m-%d') for stock in stock_data])
        open_prices = json.dumps([stock.open_price for stock in stock_data])
        close_prices = json.dumps([stock.close_price for stock in stock_data])
        high_prices = json.dumps([stock.high_price for stock in stock_data])
        low_prices = json.dumps([stock.low_price for stock in stock_data])
        return stock_dates, open_prices, close_prices, high_prices, low_prices

    def get_stock_news_data(self):
        news_counts = (
            StockNews.objects.values('published_at__date')
            .annotate(count=Count('id'))
            .order_by('published_at__date')
        )
        news_dates = json.dumps([item['published_at__date'].strftime('%Y-%m-%d') for item in news_counts])
        news_counts = json.dumps([item['count'] for item in news_counts])
        return news_dates, news_counts


from django.db.models import Count

def get_sentiment_counts_per_sector():
    # Get counts grouped by sector and sentiment label
    sentiment_counts = (
        SentimentAnalysis.objects
        .values('news__sector__name', 'sentiment_label')
        .annotate(count=Count('sentiment_label'))
    )

    sectors = list(set(item['news__sector__name'] for item in sentiment_counts))
    sentiments = ['positive', 'neutral', 'negative']

    # Initialize counts dict
    counts = {sentiment: [0 for _ in sectors] for sentiment in sentiments}

    # Map sector to index for alignment
    sector_index = {sector: i for i, sector in enumerate(sectors)}

    for item in sentiment_counts:
        sector = item['news__sector__name']
        sentiment = item['sentiment_label']
        count = item['count']

        if sentiment in sentiments:
            index = sector_index[sector]
            counts[sentiment][index] = count

    return sectors, counts


from django.db.models import Avg

def get_evaluation_metrics_per_sector():
    """
    Returns:
        all_sectors (list): List of sector names.
        accuracy_metrics (list): Corresponding average accuracy values per sector.
    """
    metrics_data = (
        EvaluationMetrics.objects
        .values('sector__name')
        .annotate(accuracy_avg=Avg('accuracy'))
    )

    all_sectors = []
    accuracy_metrics = []

    for item in metrics_data:
        sector = item['sector__name'] or 'Unknown'
        accuracy = float(item['accuracy_avg'] or 0)
        all_sectors.append(sector)
        accuracy_metrics.append(accuracy)

    return all_sectors, accuracy_metrics

